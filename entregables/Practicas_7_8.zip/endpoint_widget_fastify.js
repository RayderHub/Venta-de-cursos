const fs = require('node:fs/promises');
const path = require('node:path');
const fastify = require('fastify')({ logger: true });

const publicDir = path.join(__dirname, 'public');

const smartTvWidget = {
  titulo: 'Oferta Especial',
  mensaje: '20% de descuento en cursos de Excel',
  curso: 'Excel Avanzado',
  categoria: 'Productividad',
  descuento: '20%',
  imagen: '/assets/banners/excel-tv.png',
  enlace: '/cursos/excel-avanzado',
  estado: 'activo'
};

const wearableWidget = {
  nombre: 'SkillAcademy Wear Progress',
  dispositivo: 'Smartwatch / Wear OS',
  titulo: 'Continua tu aprendizaje',
  mensaje: 'Tienes una tarea pendiente del curso Excel Avanzado.',
  curso: 'Excel Avanzado',
  progreso: 65,
  accion: 'Ver dashboard',
  enlace: '/dashboard#tareas',
  estado: 'activo'
};

const tareas = [
  {
    id: 1,
    titulo: 'Completar modulo de formulas',
    curso: 'Excel Avanzado',
    fecha: '2026-06-22',
    prioridad: 'Alta',
    estado: 'Pendiente',
    progreso: 65,
    dispositivo: 'Web y smartwatch'
  },
  {
    id: 2,
    titulo: 'Revisar leccion de presentaciones',
    curso: 'PowerPoint Profesional',
    fecha: '2026-06-24',
    prioridad: 'Media',
    estado: 'En progreso',
    progreso: 40,
    dispositivo: 'Web'
  },
  {
    id: 3,
    titulo: 'Responder evaluacion de diseno',
    curso: 'Diseno Grafico Basico',
    fecha: '2026-06-26',
    prioridad: 'Media',
    estado: 'Pendiente',
    progreso: 20,
    dispositivo: 'Web y celular'
  },
  {
    id: 4,
    titulo: 'Publicar banner de promocion',
    curso: 'Administracion SkillAcademy',
    fecha: '2026-06-28',
    prioridad: 'Baja',
    estado: 'Completada',
    progreso: 100,
    dispositivo: 'Smart TV'
  }
];

function getDashboardStats() {
  const completadas = tareas.filter((tarea) => tarea.estado === 'Completada').length;
  const pendientes = tareas.length - completadas;
  const progresoPromedio = Math.round(
    tareas.reduce((total, tarea) => total + tarea.progreso, 0) / tareas.length
  );

  return {
    totalTareas: tareas.length,
    completadas,
    pendientes,
    progresoPromedio,
    wearableActivo: wearableWidget.estado === 'activo',
    promocionActiva: smartTvWidget.estado === 'activo'
  };
}

async function sendPublicFile(reply, fileName, contentType) {
  const filePath = path.join(publicDir, fileName);
  const content = await fs.readFile(filePath);
  return reply.type(contentType).send(content);
}

fastify.get('/api/widget/smart-tv', async () => smartTvWidget);

fastify.get('/api/widget/wearable', async () => wearableWidget);

fastify.get('/api/dashboard/tareas', async () => ({ tareas }));

fastify.get('/api/dashboard/estadisticas', async () => getDashboardStats());

fastify.get('/', async (request, reply) => sendPublicFile(reply, 'index.html', 'text/html; charset=utf-8'));

fastify.get('/dashboard', async (request, reply) => sendPublicFile(reply, 'index.html', 'text/html; charset=utf-8'));

fastify.get('/styles.css', async (request, reply) => sendPublicFile(reply, 'styles.css', 'text/css; charset=utf-8'));

fastify.get('/dashboard.js', async (request, reply) => sendPublicFile(reply, 'dashboard.js', 'application/javascript; charset=utf-8'));

fastify.listen({ port: 3000, host: '0.0.0.0' }, (err, address) => {
  if (err) {
    fastify.log.error(err);
    process.exit(1);
  }
  console.log(`Servidor iniciado en ${address}`);
});
