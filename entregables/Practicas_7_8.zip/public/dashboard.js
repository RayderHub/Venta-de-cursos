async function getJson(url) {
  const response = await fetch(url);

  if (!response.ok) {
    throw new Error(`No se pudo consultar ${url}`);
  }

  return response.json();
}

function setText(id, value) {
  const element = document.getElementById(id);
  if (element) {
    element.textContent = value;
  }
}

function renderStats(stats) {
  setText('stat-progress', `${stats.progresoPromedio}%`);
  setText('stat-total', stats.totalTareas);
  setText('stat-pending', stats.pendientes);
  setText('stat-done', stats.completadas);
}

function renderTasks(tareas) {
  const list = document.getElementById('tasks-list');

  list.innerHTML = tareas.map((tarea) => `
    <article class="task-card">
      <div>
        <h3 class="task-title">${tarea.titulo}</h3>
        <div class="task-meta">
          <span>${tarea.curso}</span>
          <span>Entrega: ${tarea.fecha}</span>
          <span>${tarea.dispositivo}</span>
          <span>Estado: ${tarea.estado}</span>
        </div>
      </div>
      <div class="task-progress">
        <span class="task-priority">${tarea.prioridad}</span>
        <span class="progress-value">${tarea.progreso}%</span>
        <div class="progress-track" aria-label="Progreso ${tarea.progreso}%">
          <span style="width: ${tarea.progreso}%"></span>
        </div>
      </div>
    </article>
  `).join('');
}

function renderWearable(widget) {
  setText('wearable-name', widget.nombre);
  setText('wearable-message', widget.mensaje);

  const progressBar = document.getElementById('wearable-progress-bar');
  const link = document.getElementById('wearable-link');

  if (progressBar) {
    progressBar.style.width = `${widget.progreso}%`;
  }

  if (link) {
    link.href = widget.enlace;
    link.textContent = widget.accion;
  }
}

async function loadDashboard() {
  const [stats, tareasResponse, wearable] = await Promise.all([
    getJson('/api/dashboard/estadisticas'),
    getJson('/api/dashboard/tareas'),
    getJson('/api/widget/wearable')
  ]);

  renderStats(stats);
  renderTasks(tareasResponse.tareas);
  renderWearable(wearable);
}

loadDashboard().catch((error) => {
  const list = document.getElementById('tasks-list');
  if (list) {
    list.innerHTML = `<p class="error-message">${error.message}</p>`;
  }
});
